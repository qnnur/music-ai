import cv2
import numpy as np
from skimage.feature import hog, local_binary_pattern

class CVProcessor:
    def __init__(self):
        self.algorithms = {
            "1. Face Detection (Haar)": self.face_detection,
            "2. SIFT Features": self.sift_features,
            "3. Canny Edges": self.canny_edges,
            "4. Color Segmentation": self.color_segmentation,
            "5. HOG Descriptor": self.hog_descriptor,
            "6. LBP Texture": self.lbp_texture,
            "7. QR Code Detection": self.qr_detection,
            "8. Optical Flow": self.optical_flow,
            "9. Image Stitching": self.image_stitching,
            "10. Background Subtraction": self.background_subtraction,
            "11. K-means Clustering": self.kmeans_clustering,
            "12. Stereo Depth": self.stereo_depth
        }

    # Реализации методов (как в предыдущем примере)
    def face_detection(self, img):
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml').detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            cv2.rectangle(img, (x,y), (x+w,y+h), (255,0,0), 2)
        return img

    # ... (остальные 11 методов)